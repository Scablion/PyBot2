import telebot
import csv
import sqlite3

global usId
global family
global age


bot = telebot.TeleBot('6352100158:AAEOcJ2HnveoSREWaphKDSZtOwBTer90L8E')
@bot.message_handler(content_types=['text'])
def get_text_messages(message):
    if message.text == '/start':
        bot.send_message(message.from_user.id, 'Как вас зовут?:')
        bot.register_next_step_handler(message, get_name)
def get_name(message):
    global name
    name = message.text
    bot.send_message(message.from_user.id, 'Какая вас фамилия?:')
    bot.register_next_step_handler(message, get_family)
def get_family(message):
    global family
    family = message.text
    bot.send_message(message.from_user.id, 'Сколько вам лет?:')
    bot.register_next_step_handler(message, get_age)

def get_age(message):
    age = message.text
    usId = message.from_user.id
    con = sqlite3.connect('Bot.db')
    cur = con.cursor()
    cur.execute('''
                CREATE TABLE IF NOT EXISTS Clients(
                id integer primary key autoincrement,
                userId text,
                nickname text,
                family text,
                age text
                )
                ''')
    cur.execute('INSERT INTO Clients(userId, nickname, family, age) VALUES (?, ?, ?, ?)', (usId, name, family, age))
    con.commit()
    cur.execute('''select * from Clients''')
    with open("outClient.csv", 'w', newline='') as csv_file:
        csv_writer = csv.writer(csv_file, delimiter=",", lineterminator='\r')
        csv_writer.writerow([i[0] for i in cur.description])
        csv_writer.writerows(cur)


bot.polling(none_stop=True)